---
name: yt-transcript
description: Get a clean, readable text transcript of a YouTube video. Use when the user gives a YouTube URL or video ID and wants the transcript, captions, subtitles, or the spoken content of the video as text. Downloads existing captions with yt-dlp, or falls back to transcribing the audio locally with whisper, then reflows the result into readable paragraphs.
---

# yt-transcript

Produce a plain-text transcript for a YouTube video and save it to a timestamped `.txt` file.

## When to use

Use this skill whenever the user supplies a YouTube URL (e.g. `https://www.youtube.com/watch?v=...`, `https://youtu.be/...`) or a bare 11-character video ID and asks for the transcript, captions, subtitles, or a text version of what is said in the video.

## Requirements

These external CLI tools must be on `PATH`:

- **`yt-dlp`** — required (fetches metadata, captions, and audio).
- **`ffmpeg`** — required only for the transcription fallback (audio extraction).
- **`whisper`** (openai-whisper) — required only when the video has no captions.

Install on macOS: `brew install yt-dlp ffmpeg` and `pip install -U openai-whisper`.

## Preflight in a sandboxed environment (e.g. the Claude app)

When this skill runs inside a code sandbox rather than a full machine, do two
quick checks before running the script — otherwise it will fail:

1. **Install yt-dlp if it's missing.** If `command -v yt-dlp` prints nothing:
   ```bash
   pip install -U yt-dlp
   ```
   (`ffmpeg`/`whisper` are only needed for the no-captions fallback.)

2. **Trust the sandbox's egress-proxy CA.** Some sandboxes route traffic through
   a TLS-intercepting proxy with a self-signed CA. yt-dlp verifies against its own
   bundled `certifi` store, which lacks that CA, so downloads fail with a cert
   error. The correct CA is **already in the system trust store** — point Python
   at it (do NOT bundle certs into this skill; there is nothing to bundle, and do
   NOT use `--no-check-certificates`):
   ```bash
   export SSL_CERT_FILE=/etc/ssl/certs/ca-certificates.crt
   export REQUESTS_CA_BUNDLE=/etc/ssl/certs/ca-certificates.crt
   export CURL_CA_BUNDLE=/etc/ssl/certs/ca-certificates.crt
   ```
   If yt-dlp still fails (its bundled `certifi` overrides the env vars), append the
   system CA into certifi's bundle:
   ```bash
   cat /etc/ssl/certs/ca-certificates.crt >> "$(python3 -m certifi)"
   ```

3. **Network allowlist.** The sandbox must allow these domains:
   `www.youtube.com`, `youtubei.googleapis.com`, `*.googlevideo.com`. After
   changing the allowlist, start a **fresh chat** so a new sandbox picks it up.

On a normal machine (your own Mac/Linux) none of this applies — just run the script.

## Usage

Run the bundled script, passing the URL or ID as the first argument:

```bash
bash yt-transcript.sh <youtube-url-or-id> [-o output_dir] [-l lang] [-m whisper_model] [-k]
```

| Option | Meaning                                       | Default           |
| ------ | --------------------------------------------- | ----------------- |
| `-o`   | output directory                              | current directory |
| `-l`   | caption language                              | `en`              |
| `-m`   | whisper model for the transcription fallback  | `small`           |
| `-k`   | keep intermediate files (`.vtt` / audio)      | off               |
| `-h`   | show help                                     | —                 |

The output file is named `ytt_YYYYMMDD_HHMMSS.txt`. The script prints the video
title, channel, length, upload date, and view count, then the path it saved to.

### Examples

```bash
# Save transcript to the current directory
bash yt-transcript.sh https://www.youtube.com/watch?v=jNQXAC9IVRw

# Bare video ID, into a chosen folder, Spanish captions
bash yt-transcript.sh -o ~/transcripts -l es dQw4w9WgXcQ

# Force a more accurate whisper model on the fallback path and keep the audio
bash yt-transcript.sh -m medium -k https://youtu.be/VIDEO_ID
```

## How it works

1. **Caption path (preferred):** `yt-dlp` downloads manual captions if present,
   else auto-generated ones, as VTT. The script strips the WEBVTT header,
   timestamps, and inline tags, drops duplicate rolling-caption lines, and
   reflows the short subtitle lines into readable paragraphs (a blank line every
   few sentences). If captions are found, it writes the text and exits.
2. **Transcription fallback:** only if no captions exist — `yt-dlp` extracts the
   audio and `whisper` transcribes it to text (copied as-is, no reflow).

After running, read the saved `.txt` file to work with the transcript (summarize,
translate, quote, etc.) as the user asked.
